using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneManager : MonoBehaviour
{
    public GameObject surfaceFinder { get; set; }

    // Start is called before the first frame update
    void Start()
    {
        surfaceFinder = GameObject.Find("SurfaceFinder");
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void DisableSurfaceFinder()
    {
        surfaceFinder.SetActive(false);
    }
    public void EnableSurfaceFinder()
    {
        surfaceFinder.SetActive(true);
    }
}
