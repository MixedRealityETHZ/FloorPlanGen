
using Microsoft.MixedReality.Toolkit.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorkspaceObjects : MonoBehaviour
{

    private SceneManager sceneManager;
    public GameObject workspaceObjects;

    // Start is called before the first frame update
    void Start()
    {
        sceneManager = FindObjectOfType<SceneManager>();
        if (sceneManager == null)
        {
            Debug.Log("SceneManager Script not found");
        }

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("l"))
        {
            PlaceWorkspace();
            print("lock workspace position");
        }

    }

    // Place workspace on a surface and lock its position and rotation
    public void PlaceWorkspace()
    {
        // Lock Transform
        Transform finderTransform = sceneManager.surfaceFinder.transform;
        workspaceObjects.transform.position = finderTransform.position;
        workspaceObjects.transform.rotation = finderTransform.rotation;

        // Disable Surface Magnetism
        sceneManager.DisableSurfaceFinder();

    }
}
