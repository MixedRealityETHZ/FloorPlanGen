using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using TMPro;

public class ImmersionManager : MonoBehaviour
{
    // Objects that are affected by the ImmersionManager settings
    public VoxelMapAdapted voxelMapAdapted;
    public GameObject drawingRadius;
    public GameObject fingertipSphere;

    public GameObject roomButtonCollection;
    public TextMeshPro roomLabel;
    public GameObject roomLabelColorObject;

    public TextMeshPro areaLabel;


    // Some Definitions in order to display the material selection in the editor

    private string[] roomtypes = new string[] { "Eraser", "Kitchen", "Living Room", "Hallway", "Bedroom A", "Bedroom B", "Bathroom A", "Bathroom B", "Dining", "Winter Garden" };

    [NamedArray(new string[] { "Outside", "Kitchen", "Living Room", "Hallway", "Bedroom A", "Bedroom B", "Bathroom A", "Bathroom B", "Dining", "Winter Garden" })]
    public Material[] roomMaterials;

    [NamedArrayAttribute(new string[] { "Outside", "Kitchen", "Living Room", "Hallway", "Bedroom A", "Bedroom B", "Bathroom A", "Bathroom B", "Dining", "Winter Garden" })]
    public Material[] transparentRoomMaterials;

    enum RoomType
    {
        OUTSIDE = 1, KITCHEN = 2, LIVINGROOM = 3, HALLWAY = 4, BEDROOMA = 5,
        BEDROOMB = 6, BATHROOMA = 7, BATHROOMB = 8, DINNE = 9, BALCONY = 10
    };


    //This function handles a change of roomtype (for example change the brush color etc.)
    public void SetRoomType(int roomtype)
    {
        ChangeBrushColor(roomtype);
        ChangeRoomLabel(roomtype);
        UpdateAreaLabel();
    }

    public void ChangeBrushColor(int materialIndex)
    {
        print("Change Brush Material: " + roomMaterials[materialIndex]);
        fingertipSphere.GetComponent<MeshRenderer>().material = roomMaterials[materialIndex];
        drawingRadius.GetComponent<MeshRenderer>().material = transparentRoomMaterials[materialIndex];
    }
    public void ChangeRoomLabel(int roomtype)
    {
        roomLabel.text = roomtypes[roomtype];
        roomLabelColorObject.GetComponent<MeshRenderer>().material = roomMaterials[roomtype];
    }

    public void UpdateAreaLabel()
    {
        VoxelGrid currentVoxelGrid = voxelMapAdapted.chunks[0];
        print(currentVoxelGrid);
        if(currentVoxelGrid != null)
        {
            string new_text = "in square meters\n\n";
            float total_area = 0;
            for (int i = 1; i < roomtypes.Length; i++)
            {
                float area = currentVoxelGrid.areas[i+1];
                total_area = total_area + area;
                string area_string = (area > 0) ? area.ToString().PadLeft(3) : "  - ";
                //area_string = area_string.PadLeft(3);
                new_text = new_text
                    + area_string
                    + "   " + roomtypes[i]
                    + "\n";
            }
            new_text = new_text
                + "_______________________\n"
                + total_area.ToString()
                + "  Total";

            areaLabel.text = new_text;
        }
    }
}
