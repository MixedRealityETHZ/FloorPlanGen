using Microsoft.MixedReality.Toolkit;
using Microsoft.MixedReality.Toolkit.UI;
using Microsoft.MixedReality.Toolkit.Utilities;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScrollRoomtypes : MonoBehaviour
{
    public GameObject buttonCollection;
    public GameObject container;

    private int numButtons = 0;
    private float itemLength = 0.0f;

    void Start()
    {
        //Get number of buttons in buttonCollection
        numButtons = buttonCollection.transform.childCount; // subtract 3 because there are 3 buffers
        itemLength = buttonCollection.GetComponent<GridObjectCollection>().CellHeight;

    }

    // The active button has an enabled Collider. The other buttons have disabled Colliders.
    public void FindActiveButton()
    {
        GameObject activeButton = null;

        Vector3 scrollPosition = container.transform.localPosition;
        float y = scrollPosition.y + itemLength;
        float absY = Mathf.Abs(y);

        //Compute which button is visible, based on the current position in the scroll wheel:
        float currentItem = absY / itemLength;
        int currentItemInt = Mathf.RoundToInt(currentItem);

        print(currentItem);
        print(currentItemInt);
        if(currentItemInt < numButtons)
        {
            activeButton = buttonCollection.transform.GetChild(currentItemInt).gameObject;
            PressButton(activeButton);
        }

        /*
        var collidersObj = buttonCollection.GetComponentsInChildren<BoxCollider>();
        for (var index = 0; index < collidersObj.Length; index++)
        {
            if(collidersObj[index] == true)
            {
                activeButton = buttonCollection.transform.GetChild(index).gameObject;
                print(activeButton);
                break;
            }
        }
        if(activeButton != null)
        {
            PressButton(activeButton);
        }
        */
    }
    public void PressButton(GameObject button)
    {
        button.GetComponent<Interactable>().OnClick.Invoke();
    }
}
