using Microsoft.MixedReality.Toolkit;
using Microsoft.MixedReality.Toolkit.Input;
using Microsoft.MixedReality.Toolkit.Utilities;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ChangeRadiusDetector : MonoBehaviour
{
    public static float pinchThreshold = 0.8f;
    public float maxPinchDistance = 0.4f;
    public static int maxRadius = 5;
    public float offset = 0.05f; // offset ensures that it's easier to select the smallest possible radius
    public GameObject visualizerObject;
    public GameObject labelObject;
    public TextMeshPro text;

    public float maxSphereScale = 12.0f;
    public float minSphereScale = 1.0f;

    [SerializeField]
    private static Handedness trackedHandLeft = Handedness.Left;
    [SerializeField]
    private static Handedness trackedHandRight = Handedness.Right;
    private static TrackedHandJoint trackedHandJoint = TrackedHandJoint.IndexTip;

    private IMixedRealityHandJointService handJointService;
    private IMixedRealityHandJointService HandJointService =>
    handJointService ??
    (handJointService = CoreServices.GetInputSystemDataProvider<IMixedRealityHandJointService>());

    // Reference to InteractionManager Script
    private InteractionManager interactionManager;


    // Start is called before the first frame update
    void Start()
    {
        interactionManager = FindObjectOfType<InteractionManager>();
        if (interactionManager == null)
        {
            Debug.Log("InteractionManager Script not found");
        }
    }

    // Update is called once per frame
    void Update()
    {        if (IsPinching(trackedHandRight) && IsPinching(trackedHandLeft))
        {
            labelObject.SetActive(true);

            var jointTransformLeft =
               HandJointService.RequestJointTransform(trackedHandJoint, trackedHandLeft);
            var jointTransformRight =
               HandJointService.RequestJointTransform(trackedHandJoint, trackedHandRight);
            
            float distance = Vector3.Distance(jointTransformLeft.position, jointTransformRight.position);
            //print("PINCHING: "+ distance);

            // if the hands are close enough, we change the brush radius according to the distance
            if (distance < maxPinchDistance)
            {
                float newRadiusFloat = Mathf.Max(0.0f, (distance * ((float)maxRadius / maxPinchDistance)) - offset);
                int newRadius = Mathf.RoundToInt(newRadiusFloat);
                interactionManager.SetAbsoluteStencilRadius( newRadius);

                float newScale = Mathf.Lerp(minSphereScale, maxSphereScale, newRadiusFloat / maxRadius);
                visualizerObject.transform.localScale = new Vector3(newScale, newScale, newScale);
                text.text = "Radius: " + (newRadius+1).ToString();
                //print("new Radius: " + newRadius);

            }

        }
        else
        {
            labelObject.SetActive(false);
        }
    }

    public bool IsPinching(Handedness trackedHand)
    {
        return HandJointService.IsHandTracked(trackedHand) && HandPoseUtils.CalculateIndexPinch(trackedHand) > pinchThreshold;
    }
}
