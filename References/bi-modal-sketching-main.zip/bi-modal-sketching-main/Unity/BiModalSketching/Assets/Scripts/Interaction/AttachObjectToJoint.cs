using Microsoft.MixedReality.Toolkit;
using Microsoft.MixedReality.Toolkit.Input;
using Microsoft.MixedReality.Toolkit.Utilities;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttachObjectToJoint : MonoBehaviour
{
    public GameObject gameObject;
    public TrackedHandJoint trackedJoint = TrackedHandJoint.IndexTip;
    public Handedness handedness = Handedness.Both;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        var handJointService = CoreServices.GetInputSystemDataProvider<IMixedRealityHandJointService>();
        if (handJointService != null)
        {
            Transform jointTransform = handJointService.RequestJointTransform(TrackedHandJoint.IndexTip, Handedness.Both);
            //Transform jointTransform = handJointService.RequestJointTransform(trackedJoint, handedness);
            print(jointTransform);
            if(jointTransform != null)
            {
                gameObject.transform.position = jointTransform.position;
                gameObject.transform.rotation = jointTransform.rotation;
            }
            
        }
    }
}
