using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractionManager : MonoBehaviour
{
    // Reference to Manager Scripts
    private AlgoManager algoManager;
    private SceneManager sceneManager;
    private HuiInteraction huiInteraction;
    private ImmersionManager immersionManager;
    private NetworkHandler networkHandler;
    private VoxelMapAdapted voxelMapAdapted;

    private int keyCooldown = 0;

    // Start is called before the first frame update
    void Start()
    {
        huiInteraction = FindObjectOfType<HuiInteraction>();
        if(huiInteraction == null)
        {
            Debug.Log("HuiInteraction Script not found");
        }
        algoManager = FindObjectOfType<AlgoManager>();
        if (algoManager == null)
        {
            Debug.Log("AlgoManager Script not found");
        }
        sceneManager = FindObjectOfType<SceneManager>();
        if (sceneManager == null)
        {
            Debug.Log("SceneManager Script not found");
        }
        immersionManager = FindObjectOfType<ImmersionManager>();
        if (immersionManager == null)
        {
            Debug.Log("ImmersionManager Script not found");
        }
        networkHandler = FindObjectOfType<NetworkHandler>();
        if (networkHandler == null)
        {
            Debug.Log("networkHandler Script not found");
        }
        voxelMapAdapted = FindObjectOfType<VoxelMapAdapted>();
        if (voxelMapAdapted == null)
        {
            Debug.Log("voxelMapAdapted Script not found");
        }

    }

    // Update is called once per frame
    void Update()
    {
        /*
         * Please connect me to upload
            StartCoroutine(networkHandler.Upload(algoManager.StringifyCurrentFloorPlan()));
            Debug.Log("Floorplan pushed to magic website from Holo-Mode");
        */

        /* Please connect me to download
            StartCoroutine(networkHandler.Download(algoManager));
            Debug.Log("Floorplan pushed to magic website from Holo-Mode");
        */

        /// DEBUG

        if (keyCooldown > 100)
        {
            if (Input.GetKey(KeyCode.Alpha1))
            {
                algoManager.SaveCurrentFloorPlan();
                Debug.Log("This action will have consequences");
                keyCooldown = 0;
            }
            if (Input.GetKey(KeyCode.Alpha2))
            {
                algoManager.LoadFloorPlan();
                Debug.Log("Butterfly");
                keyCooldown = 0;
            }
            if (Input.GetKey(KeyCode.Alpha3))
            {
                StartCoroutine(networkHandler.Upload(algoManager.StringifyCurrentFloorPlan()));
                Debug.Log("Floorplan pushed to magic website from Holo-Mode");
                keyCooldown = 0;
            }
            if (Input.GetKey(KeyCode.Alpha4))
            {
                StartCoroutine(networkHandler.Download(algoManager));
                Debug.Log("Floorplan pulled to magic website from Holo-Mode");
                keyCooldown = 0;
            }
            if (Input.GetKey(KeyCode.Alpha5))
            {
                VoxelGrid currentVoxelGrid = voxelMapAdapted.chunks[0];
                Debug.Log("Total outside area: " + currentVoxelGrid.areas[(int)RoomType.OUTSIDE]);
                Debug.Log("Total kitchen area: " + currentVoxelGrid.areas[(int)RoomType.KITCHEN]);
                keyCooldown = 0;
            }
        }
        keyCooldown++;

        /// END DEBUG

    }

    public void SavePlan()
    {
        StartCoroutine(networkHandler.Upload(algoManager.StringifyCurrentFloorPlan()));
        Debug.Log("Floorplan pushed to magic website from Holo-Mode");
    }

    public void LoadPlan()
    {
        StartCoroutine(networkHandler.Download(algoManager));
        Debug.Log("Floorplan pulled from magic website from Immersive Mode");
    }

    public void SetRoomType(int roomtype)
    {
        algoManager.SetRoomType(roomtype);
        immersionManager.SetRoomType(roomtype); // This changes the brush color
    }

    public void MoveWorkspace()
    {
        sceneManager.EnableSurfaceFinder();
    }

    public void UpdateStencilRadius(bool increase)
    {
        algoManager.UpdateStencilRadius(increase);
    }
    
    public void SetStencilType(int stenciltype)
    {
        algoManager.SetStencilType(stenciltype);
    }

    public void SetAbsoluteStencilRadius(int size)
    {
        algoManager.SetAbsoluteStencilRadius(size);
    }
}
