using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HuiInteraction : MonoBehaviour
{
    // Reference to InteractionManager Script
    private InteractionManager interactionManager;

    enum RoomType
    {
        OUTSIDE = 1, KITCHEN = 2, LIVINGROOM = 3, HALLWAY = 4, BEDROOMA = 5,
        BEDROOMB = 6, BATHROOMA = 7, BATHROOMB = 8, DINNE = 9, BALCONY = 10
    };
    int radius = 1;
    // Start is called before the first frame update
    void Start()
    {
        interactionManager = FindObjectOfType<InteractionManager>();
        if (interactionManager == null)
        {
            Debug.Log("InteractionManager Script not found");
        }

    }

    // Handles the buttons to select the room type
    public void SelectRoomType(int roomtype)
    {
        Debug.Log("roomtype " + roomtype);
        interactionManager.SetRoomType(roomtype-1);
    }

    public void MoveWorkspace()
    {
        interactionManager.MoveWorkspace();
    }

    // Handles the buttons to select the radius
    public void UpdateStencilRadius(bool increase)
    {
        var txt = increase ? "increased" : "decreased";
        Debug.Log("radius " + txt);
        interactionManager.UpdateStencilRadius(increase);
    }
    
    // handles the buttons to update stencil type
    // 0 - square | 1 - circle
    public void SetStencilType(int type)
    {
        Debug.Log("stencil type " + type);
        interactionManager.SetStencilType(type);
    }

}
