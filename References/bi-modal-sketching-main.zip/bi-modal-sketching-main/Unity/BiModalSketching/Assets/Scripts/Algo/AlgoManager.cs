using Newtonsoft.Json;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class AlgoManager : MonoBehaviour
{
    private VoxelMapAdapted voxelMapAdapted;
    private string oldFloorplan = "";

    // Start is called before the first frame update
    void Start()
    {
        voxelMapAdapted = FindObjectOfType<VoxelMapAdapted>();
        if (voxelMapAdapted == null)
        {
            Debug.Log("VoxelMapAdapted Script not found");
        }

    }
    public void SaveCurrentFloorPlan()
    {
        File.WriteAllText("myjson.json", this.StringifyCurrentFloorPlan());
    }

    public string StringifyCurrentFloorPlan()
    {
        return JsonConvert.SerializeObject(this.voxelMapAdapted.chunks[0]);
    }

    public void LoadFloorPlanFromString(string json_data)
    {
        /*if (oldFloorplan == json_data)
        {
            return;
        }
        */
        //oldFloorplan = json_data;
        VoxelGrid loaded = JsonConvert.DeserializeObject<VoxelGrid>(json_data);
        Destroy(voxelMapAdapted.chunks[0].gameObject);
        voxelMapAdapted.CreateChunk(0, 0, 0);
        //voxelMapAdapted.transform.localRotation = Quaternion.AngleAxis(90, new Vector3(1.0f, 0.0f, 0.0f));

        for (int i = 0; i < loaded.voxels.Length; i++)
        {
            voxelMapAdapted.chunks[0].voxels[i].state = loaded.voxels[i].state;
            voxelMapAdapted.chunks[0].voxels[i].WallTypes[0] = loaded.voxels[i].WallTypes[0];
            voxelMapAdapted.chunks[0].voxels[i].WallTypes[1] = loaded.voxels[i].WallTypes[1];
            voxelMapAdapted.chunks[0].voxels[i].WallTypes[2] = loaded.voxels[i].WallTypes[2];
            voxelMapAdapted.chunks[0].voxels[i].WallTypes[3] = loaded.voxels[i].WallTypes[3];
        }
        voxelMapAdapted.chunks[0].Refresh();
    }

    public string LoadFloorPlan(string name = "myjson.json")
    {
        return File.ReadAllText(name);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void SetRoomType(int roomtype)
    {
        voxelMapAdapted.fillTypeIndex = roomtype;
    }

    public void SetStencilType(int stenciltype)
    {
        voxelMapAdapted.stencilIndex = stenciltype;
    }

    public void UpdateStencilRadius(bool increase)
    {
        voxelMapAdapted.UpdateStencilRadius(increase);
    }

    public void SetAbsoluteStencilRadius(int size)
    {
        voxelMapAdapted.SetAbsoluteStencilRadius(size);
    }

}
