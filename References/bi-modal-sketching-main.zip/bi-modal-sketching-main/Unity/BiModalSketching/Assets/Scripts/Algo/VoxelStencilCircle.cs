using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VoxelStencilCircle : VoxelStencil
{

	private int sqrRadius;

	public override void Initialize(RoomType fillType, int radius)
	{
		base.Initialize(fillType, radius);
		sqrRadius = radius * radius;
	}

	public override RoomType Apply(int x, int y, RoomType voxel)
	{
		x -= centerX;
		y -= centerY;
		if (x * x + y * y <= sqrRadius)
		{
			return fillType;
		}
		return voxel;
	}
}