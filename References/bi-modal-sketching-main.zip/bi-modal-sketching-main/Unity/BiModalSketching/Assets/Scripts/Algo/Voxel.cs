using UnityEngine;
using System;
using System.Collections.Generic;
using Newtonsoft.Json;

[JsonObject(MemberSerialization.OptIn)]
[Serializable]
public class Voxel : MonoBehaviour
{
	[JsonProperty]
	public RoomType state = RoomType.OUTSIDE;
	private GameObject[] indoorWalls;
	private GameObject[] windowWalls;
	[JsonProperty]
	public float size;
	[JsonProperty]
	public int x, y;
	[JsonProperty]
	public WallType[] WallTypes;
	private readonly Transform ptransform;
	public Vector2 position, xEdgePosition, yEdgePosition, middlePosition;
	public bool isEdge = false;
	public Voxel leftNeighbour = null;
	public Voxel downNeighbour = null;
	public Voxel diagNeighbour = null;

	public Voxel(int x, int y, float size, Transform ptransform, GameObject wallPrefab, GameObject windowPrefab, int grid_resolution)
	{

		this.ptransform = ptransform;
		this.indoorWalls = new GameObject[4];
		this.windowWalls = new GameObject[4];

		this.size = size;
		this.x = x;
		this.y = y;

		if (x == 0 || y == 0 || x == grid_resolution - 1 || y == grid_resolution - 1)
        {
			isEdge = true;
        }

		position.x = (x + 0.5f) * size;
		position.y = (y + 0.5f) * size;

		xEdgePosition = position;
		xEdgePosition.x += size * 0.5f;
		yEdgePosition = position;
		yEdgePosition.y += size * 0.5f;
		middlePosition = position;
		middlePosition.x += size * 0.5f;
		middlePosition.y += size * 0.5f;

		WallTypes = new WallType[] { WallType.WALL, WallType.WALL, WallType.WALL, WallType.WALL };

		AddIndoorWalls(wallPrefab);
		AddWindows(windowPrefab);
	}

	public Voxel() { }

	public void ShowIndoorWall(int idx)
    {
		indoorWalls[idx].SetActive(true);
	}

	public void HideIndoorWall(int idx)
	{
		indoorWalls[idx].SetActive(false);
	}

	public void ShowWindow(int idx)
	{
		windowWalls[idx].SetActive(true);
	}

	public void HideWindow(int idx)
	{
		windowWalls[idx].SetActive(false);
	}

	public void HideIndoorWalls()
	{
		indoorWalls[0].SetActive(false);
		indoorWalls[1].SetActive(false);
		indoorWalls[2].SetActive(false);
		indoorWalls[3].SetActive(false);
	}

	public void HideWindows()
	{
		windowWalls[0].SetActive(false);
		windowWalls[1].SetActive(false);
		windowWalls[2].SetActive(false);
		windowWalls[3].SetActive(false);
	}

	private void AddIndoorWalls(GameObject wallPrefab)
    {
		indoorWalls[0] = AddIndoorWall(wallPrefab, 0);
		indoorWalls[1] = AddIndoorWall(wallPrefab, 1);
		indoorWalls[2] = AddIndoorWall(wallPrefab, 2);
		indoorWalls[3] = AddIndoorWall(wallPrefab, 3);
	}

	private void AddWindows(GameObject windowPrefab)
	{
		windowWalls[0] = AddIndoorWall(windowPrefab, 0);
		windowWalls[1] = AddIndoorWall(windowPrefab, 1);
		windowWalls[2] = AddIndoorWall(windowPrefab, 2);
		windowWalls[3] = AddIndoorWall(windowPrefab, 3);
	}

	private GameObject AddIndoorWall(GameObject wallPrefab, int rotation)
    {
		GameObject o = Instantiate(wallPrefab) as GameObject;
		o.transform.parent = this.ptransform.parent;
		o.transform.localPosition = middlePosition;
		o.transform.localScale = Vector3.one * size;
		o.transform.rotation = ptransform.rotation;
		o.transform.Rotate(new Vector3(0, 0, 1), rotation * 90);
		o.SetActive(false);
		return o;
	}

	public void BecomeXDummyOf(Voxel voxel, float offset)
	{
		state = voxel.state;
		position = voxel.position;
		xEdgePosition = voxel.xEdgePosition;
		yEdgePosition = voxel.yEdgePosition;
		position.x += offset;
		xEdgePosition.x += offset;
		yEdgePosition.x += offset;
	}

	public void BecomeYDummyOf(Voxel voxel, float offset)
	{
		state = voxel.state;
		position = voxel.position;
		xEdgePosition = voxel.xEdgePosition;
		yEdgePosition = voxel.yEdgePosition;
		position.y += offset;
		xEdgePosition.y += offset;
		yEdgePosition.y += offset;
	}

	public void BecomeXYDummyOf(Voxel voxel, float offset)
	{
		state = voxel.state;
		position = voxel.position;
		xEdgePosition = voxel.xEdgePosition;
		yEdgePosition = voxel.yEdgePosition;
		position.x += offset;
		position.y += offset;
		xEdgePosition.x += offset;
		xEdgePosition.y += offset;
		yEdgePosition.x += offset;
		yEdgePosition.y += offset;
	}
}