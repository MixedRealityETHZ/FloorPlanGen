using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum RoomType { OUTSIDE = 1, KITCHEN = 2, LIVINGROOM = 3, HALLWAY = 4, BEDROOMA = 5,
    BEDROOMB = 6, BATHROOMA = 7, BATHROOMB = 8, DINNE = 9, BALCONY = 10  };

public enum WallType { WALL = 1, NO_WALL = 2, WINDOW = 3, DOOR = 4 };


[JsonObject(MemberSerialization.OptIn)]
[SelectionBase]
public class VoxelGrid : MonoBehaviour
{
    [JsonProperty]
    public int resolution;

    public GameObject voxelPrefab;
    public GameObject indoorWallPrefab;
    public GameObject WindowPrefab;
    public VoxelGrid xNeighbor, yNeighbor, xyNeighbor;

    [JsonProperty]
    private const int NUMROOMS = 12;

    private Mesh mesh;

    private List<Vector3> vertices;
    private List<int>[] rooms;
    private List<int> walls;

    public float[] areas;

    [JsonProperty]
    public Voxel[] voxels;
    [JsonProperty]
    public float voxelSize, gridSize;
    private Voxel dummyX, dummyY, dummyT;

    private ImmersionManager immersionManager;

    void Awake()
    {
        immersionManager = FindObjectOfType<ImmersionManager>();
        if (immersionManager == null)
        {
            Debug.Log("ImmersionManager Script not found");
        }
    }

    public void Initialize(int resolution, float size, Transform ptransform)
    {
        immersionManager = FindObjectOfType<ImmersionManager>();
        if (immersionManager == null)
        {
            Debug.Log("ImmersionManager Script not found");
        }

        this.resolution = resolution;
        gridSize = size;
        voxelSize = size / resolution;
        voxels = new Voxel[resolution * resolution];

        //dummyX = new Voxel();
        //dummyY = new Voxel();
        //dummyT = new Voxel();

        for (int i = 0, y = 0; y < resolution; y++)
        {
            for (int x = 0; x < resolution; x++, i++)
            {
                CreateVoxel(i, x, y);
                if (y != 0)
                {
                    voxels[i].downNeighbour = voxels[i - resolution];
                }
                if (x != 0)
                {
                    voxels[i].leftNeighbour = voxels[i - 1];
                }
                if (x != 0 && y != 0)
                {
                    voxels[i].diagNeighbour = voxels[i - resolution - 1];
                }
            }
        }
        transform.rotation = ptransform.rotation;
        GetComponent<MeshFilter>().mesh = mesh = new Mesh();

        mesh.name = "Room Mesh";
        vertices = new List<Vector3>();
        rooms = new List<int>[NUMROOMS];
        areas = new float[NUMROOMS];
        for (int i = 0; i < rooms.Length; i++)
        {
            rooms[i] = new List<int>();
        }
        walls = new List<int>();
        Refresh();
    }

    private void CreateVoxel(int i, int x, int y)
    {
        GameObject o = Instantiate(voxelPrefab) as GameObject;
        o.transform.localPosition = new Vector3((x + 0.5f) * voxelSize, (y + 0.5f) * voxelSize, 0);
        o.transform.localScale = Vector3.one * voxelSize * 0.1f;
        o.transform.parent = transform;
        voxels[i] = new Voxel(x, y, voxelSize, o.transform, indoorWallPrefab, WindowPrefab, resolution);
    }

    public void Apply(VoxelStencil stencil)
    {
        int xStart = stencil.XStart;
        if (xStart < 0)
        {
            xStart = 0;
        }
        int xEnd = stencil.XEnd;
        if (xEnd >= resolution)
        {
            xEnd = resolution - 1;
        }
        int yStart = stencil.YStart;
        if (yStart < 0)
        {
            yStart = 0;
        }
        int yEnd = stencil.YEnd;
        if (yEnd >= resolution)
        {
            yEnd = resolution - 1;
        }

        for (int y = yStart; y <= yEnd; y++)
        {
            int i = y * resolution + xStart;
            for (int x = xStart; x <= xEnd; x++, i++)
            {
                if (!voxels[i].isEdge)
                {
                    voxels[i].state = stencil.Apply(x, y, voxels[i].state);
                }
                else
                {
                    voxels[i].state = RoomType.OUTSIDE;
                }
                resetWalltypeOffNeigbours(voxels[i]);
            }
        }
        Refresh();
    }

    public void resetWalltypeOffNeigbours(Voxel a)
    {
        if (!(a.leftNeighbour is null))
        {
            a.leftNeighbour.WallTypes[1] = WallType.WALL;
            a.leftNeighbour.WallTypes[2] = WallType.WALL;
        }
        if (!(a.downNeighbour is null))
        {
            a.downNeighbour.WallTypes[0] = WallType.WALL;
            a.downNeighbour.WallTypes[3] = WallType.WALL;
        }
        if (!(a.diagNeighbour is null))
        {
            a.diagNeighbour.WallTypes[3] = WallType.WALL;
            a.diagNeighbour.WallTypes[2] = WallType.WALL;
        }
        a.WallTypes[0] = WallType.WALL;
        a.WallTypes[1] = WallType.WALL;
    }

    public void Refresh()
    {
        Triangulate();
        immersionManager.UpdateAreaLabel();
    }

    private void Triangulate()
    {
        vertices.Clear();
        for (int i = 0; i < rooms.Length; i++)
        {
            rooms[i].Clear();
        }
        walls.Clear();
        mesh.Clear();
        areas = new float[NUMROOMS];
        foreach (Voxel voxel in voxels)
        {
            voxel.HideIndoorWalls();
            voxel.HideWindows();
        }

        mesh.subMeshCount = NUMROOMS + 1;

        if (xNeighbor != null)
        {
            dummyX.BecomeXDummyOf(xNeighbor.voxels[0], gridSize);
        }

        TriangulateCellRows();
        if (yNeighbor != null)
        {
            TriangulateGapRow();
        }

        mesh.vertices = vertices.ToArray();

        for (int i = 0; i < rooms.Length; i++)
        {
            mesh.SetTriangles(rooms[i].ToArray(), i + 1);
        }
        

    }

    private void TriangulateCellRows()
    {
        int cells = resolution - 1;
        for (int i = 0, y = 0; y < cells; y++, i++)
        {
            for (int x = 0; x < cells; x++, i++)
            {
                TriangulateCell(voxels[i],
                    voxels[i + 1],
                    voxels[i + resolution],
                    voxels[i + resolution + 1]);
            }
            if (xNeighbor != null)
            {
                TriangulateGapCell(i);
            }
        }
    }

    private void TriangulateGapCell(int i)
    {
        Voxel dummySwap = dummyT;
        dummySwap.BecomeXDummyOf(xNeighbor.voxels[i + 1], gridSize);
        dummyT = dummyX;
        dummyX = dummySwap;
        TriangulateCell(voxels[i], dummyT, voxels[i + resolution], dummyX);
    }

    private void TriangulateGapRow()
    {
        dummyY.BecomeYDummyOf(yNeighbor.voxels[0], gridSize);
        int cells = resolution - 1;
        int offset = cells * resolution;

        for (int x = 0; x < cells; x++)
        {
            Voxel dummySwap = dummyT;
            dummySwap.BecomeYDummyOf(yNeighbor.voxels[x + 1], gridSize);
            dummyT = dummyY;
            dummyY = dummySwap;
            TriangulateCell(voxels[x + offset], voxels[x + offset + 1], dummyT, dummyY);
        }

        if (xNeighbor != null)
        {
            dummyT.BecomeXYDummyOf(xyNeighbor.voxels[0], gridSize);
            TriangulateCell(voxels[voxels.Length - 1], dummyX, dummyY, dummyT);
        }
    }

    private void TriangulateCell(Voxel a, Voxel b, Voxel c, Voxel d)
    {
        AddRoom(a.position, a.yEdgePosition, a.middlePosition, a.xEdgePosition, a.state);
        AddRoom(b.position, a.xEdgePosition, a.middlePosition, b.yEdgePosition, b.state);
        AddRoom(c.position, c.xEdgePosition, a.middlePosition, a.yEdgePosition, c.state);
        AddRoom(d.position, b.yEdgePosition, a.middlePosition, c.xEdgePosition, d.state);

        if (c.state != d.state) PrefabSelector(a, 3);
        if (d.state != b.state) PrefabSelector(a, 2);
        if (a.state != b.state) PrefabSelector(a, 1);
        if (a.state != c.state) PrefabSelector(a, 0);
    }

    private void PrefabSelector(Voxel a, int idx)
    {
        if (a.WallTypes[idx] == WallType.WALL)
        {
            a.ShowIndoorWall(idx);
        }
        else if (a.WallTypes[idx] == WallType.WINDOW)
        {
            a.ShowWindow(idx);
        }
    }

    private void AddRoom(Vector3 a, Vector3 b, Vector3 c, Vector3 d, RoomType roomType)
    {
        areas[(int) roomType] += 0.25f;
        int vertexIndex = vertices.Count;
        vertices.Add(a);
        vertices.Add(b);
        vertices.Add(c);
        vertices.Add(d);
        rooms[(int)roomType - 1].Add(vertexIndex);
        rooms[(int)roomType - 1].Add(vertexIndex + 1);
        rooms[(int)roomType - 1].Add(vertexIndex + 2);
        rooms[(int)roomType - 1].Add(vertexIndex);
        rooms[(int)roomType - 1].Add(vertexIndex + 2);
        rooms[(int)roomType - 1].Add(vertexIndex + 3);
    }
}
