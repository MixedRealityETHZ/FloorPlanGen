using Newtonsoft.Json;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class AlgoManager : MonoBehaviour
{
    private VoxelMapAdapted voxelMapAdapted;
    private string oldFloorplan = "";
    public Dropdown dropdown;
    private bool dropdownVisible = false;
    public float elapsedTime;

    // Start is called before the first frame update
    void Start()
    {
        voxelMapAdapted = FindObjectOfType<VoxelMapAdapted>();
        if (voxelMapAdapted == null)
        {
            Debug.Log("VoxelMapAdapted Script not found");
        }

        LoadFloorPlan();

        dropdown.gameObject.SetActive(false);
        elapsedTime = 0.0f;
    }
    public void SaveCurrentFloorPlan()
    {
        File.WriteAllText("myjson.json", this.StringifyCurrentFloorPlan());
    }

    public string StringifyCurrentFloorPlan()
    {
       return JsonConvert.SerializeObject(this.voxelMapAdapted.chunks[0]);
    }


    public void LoadFloorPlanFromString(string json_data)
    {
        VoxelGrid loaded = JsonConvert.DeserializeObject<VoxelGrid>(json_data);
        Destroy(voxelMapAdapted.chunks[0].gameObject);
        voxelMapAdapted.CreateChunk(0, 0, 0);
        voxelMapAdapted.transform.localRotation = Quaternion.AngleAxis(90, new Vector3(1.0f, 0.0f, 0.0f));

        for (int i = 0; i < loaded.voxels.Length; i++)
        {
            voxelMapAdapted.chunks[0].voxels[i].state = loaded.voxels[i].state;
            voxelMapAdapted.chunks[0].voxels[i].WallTypes[0] = loaded.voxels[i].WallTypes[0];
            voxelMapAdapted.chunks[0].voxels[i].WallTypes[1] = loaded.voxels[i].WallTypes[1];
            voxelMapAdapted.chunks[0].voxels[i].WallTypes[2] = loaded.voxels[i].WallTypes[2];
            voxelMapAdapted.chunks[0].voxels[i].WallTypes[3] = loaded.voxels[i].WallTypes[3];
        }
        voxelMapAdapted.chunks[0].Refresh();
    }

    public void LoadFloorPlan(string name = "myjson.json")
    {
        LoadFloorPlanFromString(File.ReadAllText(name));
    }

    // Update is called once per frame
    void Update()
    {
        elapsedTime += Time.deltaTime;
        if (elapsedTime >= 0.08f)
        {
            elapsedTime = 0.0f;
            if (Input.GetKey(KeyCode.Tab))
            {
                if (!dropdownVisible)
                {
                    dropdown.transform.position = Input.mousePosition;
                    dropdown.gameObject.SetActive(true);
                    voxelMapAdapted.chunks[0].modificationsEnabled = false;
                    dropdownVisible = true;
                }
                else 
                {
                    dropdown.gameObject.SetActive(false);
                    dropdownVisible = false;
                    voxelMapAdapted.chunks[0].modificationsEnabled = true;
                }
            }
        }
    }

    public void SetWallModifyType()
    {
        switch (dropdown.value)
        {
            case 0:
                voxelMapAdapted.chunks[0].modifyWallType = WallType.DOOR;
                voxelMapAdapted.chunks[0].modificationsEnabled = true;
                dropdown.gameObject.SetActive(false);
                dropdownVisible = false;
                break;

            case 1:
                voxelMapAdapted.chunks[0].modifyWallType = WallType.WINDOW;
                voxelMapAdapted.chunks[0].modificationsEnabled = true;
                dropdown.gameObject.SetActive(false);
                dropdownVisible = false;
                break;

            case 2:
                voxelMapAdapted.chunks[0].modifyWallType = WallType.WALL;
                voxelMapAdapted.chunks[0].modificationsEnabled = true;
                dropdown.gameObject.SetActive(false);
                dropdownVisible = false;
                break;

            case 3:
                voxelMapAdapted.chunks[0].modifyWallType = WallType.NO_WALL;
                voxelMapAdapted.chunks[0].modificationsEnabled = true;
                dropdown.gameObject.SetActive(false);
                dropdownVisible = false;
                break;

            default:
                Debug.Log("invalid wall type");
                break;
        }
    }

    public void SetRoomType(int roomtype)
    {
        voxelMapAdapted.fillTypeIndex = roomtype;
    }

    public void SetStencilType(int stenciltype)
    {
        voxelMapAdapted.stencilIndex = stenciltype;
    }

    public void UpdateStencilRadius(bool increase)
    {
        voxelMapAdapted.UpdateStencilRadius(increase);
    }
}
