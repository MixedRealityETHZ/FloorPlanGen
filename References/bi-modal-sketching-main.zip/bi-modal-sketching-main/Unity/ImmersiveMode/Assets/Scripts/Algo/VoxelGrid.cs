using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum RoomType { OUTSIDE = 1, KITCHEN = 2, LIVINGROOM = 3, HALLWAY = 4, BEDROOMA = 5,
    BEDROOMB = 6, BATHROOMA = 7, BATHROOMB = 8, DINNE = 9, BALCONY = 10  };

public enum WallType { WALL = 1, NO_WALL = 2, WINDOW = 3, DOOR = 4 };

[JsonObject(MemberSerialization.OptIn)]
[SelectionBase]
public class VoxelGrid : MonoBehaviour
{
    [JsonProperty]
    public int resolution;

    public GameObject voxelPrefab;
    public GameObject indoorWallPrefab;
    public GameObject windowWallPrefab;
    public GameObject doorWallPrefab;
    public GameObject ceilingPrefab;

    public VoxelGrid xNeighbor, yNeighbor, xyNeighbor;

    [JsonProperty]
    private const int NUMROOMS = 12;

    private Mesh mesh;

    private List<Vector3> vertices;
    private List<int>[] rooms;
    private List<int> walls;
    public WallType modifyWallType;
    private float elapsedTime = 0.0f;
    public int wallModificationType { get; set; }
    private GameObject previousWall;
    private bool previewEnabled = false;
    public bool modificationsEnabled = true;

    [JsonProperty]
    public Voxel[] voxels;
    [JsonProperty]
    public float voxelSize, gridSize;
    private Voxel dummyX, dummyY, dummyT;

    public void Initialize(int resolution, float size, Transform ptransform)
    {
        this.resolution = resolution;
        gridSize = size;
        voxelSize = size / resolution;
        voxels = new Voxel[resolution * resolution];

        modifyWallType = WallType.DOOR;

        for (int i = 0, y = 0; y < resolution; y++)
        {
            for (int x = 0; x < resolution; x++, i++)
            {
                CreateVoxel(i, x, y);
            }
        }
        transform.rotation = ptransform.rotation;
        GetComponent<MeshFilter>().mesh = mesh = new Mesh();

        mesh.name = "Room Mesh";
        vertices = new List<Vector3>();
        rooms = new List<int>[NUMROOMS];
        for (int i = 0; i < rooms.Length; i++)
        {
            rooms[i] = new List<int>();
        }
        walls = new List<int>();
        Refresh();
    }

    private void CreateVoxel(int i, int x, int y)
    {
        GameObject o = Instantiate(voxelPrefab) as GameObject;
        o.transform.localPosition = new Vector3((x + 0.5f) * voxelSize, (y + 0.5f) * voxelSize, 0);
        o.transform.localScale = Vector3.one * voxelSize * 0.1f;
        o.transform.parent = transform;
        voxels[i] = new Voxel(x, y, voxelSize, o.transform, indoorWallPrefab, windowWallPrefab, doorWallPrefab, ceilingPrefab);
    }

    private void Update()
    {
        elapsedTime += Time.deltaTime;
        if (elapsedTime >= 0.1f)
        {
            elapsedTime = 0.0f;
            if (Input.GetMouseButton(0) && modificationsEnabled)
            {
                RaycastHit hitInfo;
                int wallsLayer = 3;
                int wallsMask = 1 << wallsLayer;

                int doorsLayer = 7;
                int doorsMask = 1 << 7;

                int combinedMask = doorsMask | wallsMask;

                // only detect collisions with the wallsLayer
                if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hitInfo, Mathf.Infinity, combinedMask))
                {
                    GameObject parentWall = hitInfo.collider.gameObject.transform.parent.gameObject;
                    Wall wall = parentWall.GetComponent<Wall>();
                    voxels[wall.y * resolution + wall.x].indoorWalls[wall.wallIndex].SetActive(false);
                    voxels[wall.y * resolution + wall.x].windowWalls[wall.wallIndex].SetActive(false);
                    voxels[wall.y * resolution + wall.x].doorWalls[wall.wallIndex].SetActive(false);

                    switch (modifyWallType)
                    {
                        case WallType.WALL:
                            GameObject o = voxels[wall.y * resolution + wall.x].indoorWalls[wall.wallIndex];
                            o.SetActive(true);
                            if (previewEnabled)
                            {
                                if (previousWall != null)
                                {
                                    previousWall.SetActive(true);
                                }
                                previewEnabled = false;
                            }
                            break;

                        case WallType.WINDOW:
                            o = voxels[wall.y * resolution + wall.x].windowWalls[wall.wallIndex];
                            o.SetActive(true);
                            if (previewEnabled)
                            {
                                if (previousWall != null)
                                {
                                    previousWall.SetActive(true);
                                }
                                previewEnabled = false;
                            }
                            break;

                        case WallType.DOOR:
                            o = voxels[wall.y * resolution + wall.x].doorWalls[wall.wallIndex];
                            o.SetActive(true);
                            if (previewEnabled)
                            {
                                if (previousWall != null)
                                {
                                    previousWall.SetActive(true);
                                }
                                previewEnabled = false;
                            }
                            break;

                        case WallType.NO_WALL:
                            previewEnabled = true;
                            if (previousWall != null)
                            {
                                previousWall.SetActive(true);
                            }
                            previousWall = voxels[wall.y * resolution + wall.x].indoorWalls[wall.wallIndex];
                            break;

                        default:
                            Debug.Log("invalid wall type");
                            break;
                    }

                    voxels[wall.y * resolution + wall.x].WallTypes[wall.wallIndex] = modifyWallType;
                }
            }
        }
    }

    public void Apply(VoxelStencil stencil)
    {
        int xStart = stencil.XStart;
        if (xStart < 0)
        {
            xStart = 0;
        }
        int xEnd = stencil.XEnd;
        if (xEnd >= resolution)
        {
            xEnd = resolution - 1;
        }
        int yStart = stencil.YStart;
        if (yStart < 0)
        {
            yStart = 0;
        }
        int yEnd = stencil.YEnd;
        if (yEnd >= resolution)
        {
            yEnd = resolution - 1;
        }

        for (int y = yStart; y <= yEnd; y++)
        {
            int i = y * resolution + xStart;
            for (int x = xStart; x <= xEnd; x++, i++)
            {
                voxels[i].state = stencil.Apply(x, y, voxels[i].state);
            }
        }
        Refresh();

        //transform.localRotation = Quaternion.AngleAxis(-90, new Vector3(1.0f, 0.0f, 0.0f));
    }

    public void Refresh()
    {
        Triangulate();
    }

    private void Triangulate()
    {
        vertices.Clear();
        for (int i = 0; i < rooms.Length; i++)
        {
            rooms[i].Clear();
        }
        walls.Clear();
        mesh.Clear();
        foreach (Voxel voxel in voxels)
        {
            voxel.HideWalls();
            voxel.HideCeiling();
        }

        mesh.subMeshCount = NUMROOMS + 1;

        if (xNeighbor != null)
        {
            dummyX.BecomeXDummyOf(xNeighbor.voxels[0], gridSize);
        }

        TriangulateCellRows();
        if (yNeighbor != null)
        {
            TriangulateGapRow();
        }

        mesh.vertices = vertices.ToArray();

        for (int i = 0; i < rooms.Length; i++)
        {
            mesh.SetTriangles(rooms[i].ToArray(), i + 1);
        }
    }

    private void TriangulateCellRows()
    {
        int cells = resolution - 1;
        for (int i = 0, y = 0; y < cells; y++, i++)
        {
            for (int x = 0; x < cells; x++, i++)
            {
                TriangulateCell(voxels[i],
                    voxels[i + 1],
                    voxels[i + resolution],
                    voxels[i + resolution + 1]);
            }
            if (xNeighbor != null)
            {
                TriangulateGapCell(i);
            }
        }
    }

    private void TriangulateGapCell(int i)
    {
        Voxel dummySwap = dummyT;
        dummySwap.BecomeXDummyOf(xNeighbor.voxels[i + 1], gridSize);
        dummyT = dummyX;
        dummyX = dummySwap;
        TriangulateCell(voxels[i], dummyT, voxels[i + resolution], dummyX);
    }

    private void TriangulateGapRow()
    {
        dummyY.BecomeYDummyOf(yNeighbor.voxels[0], gridSize);
        int cells = resolution - 1;
        int offset = cells * resolution;

        for (int x = 0; x < cells; x++)
        {
            Voxel dummySwap = dummyT;
            dummySwap.BecomeYDummyOf(yNeighbor.voxels[x + 1], gridSize);
            dummyT = dummyY;
            dummyY = dummySwap;
            TriangulateCell(voxels[x + offset], voxels[x + offset + 1], dummyT, dummyY);
        }

        if (xNeighbor != null)
        {
            dummyT.BecomeXYDummyOf(xyNeighbor.voxels[0], gridSize);
            TriangulateCell(voxels[voxels.Length - 1], dummyX, dummyY, dummyT);
        }
    }

    private void TriangulateCell(Voxel a, Voxel b, Voxel c, Voxel d)
    {
        AddRoom(a.position, a.yEdgePosition, a.middlePosition, a.xEdgePosition, a.state);
        AddRoom(b.position, a.xEdgePosition, a.middlePosition, b.yEdgePosition, b.state);
        AddRoom(c.position, c.xEdgePosition, a.middlePosition, a.yEdgePosition, c.state);
        AddRoom(d.position, b.yEdgePosition, a.middlePosition, c.xEdgePosition, d.state);

        if (c.state != d.state) a.ShowWall(3);
        if (d.state != b.state) a.ShowWall(2);
        if (a.state != b.state) a.ShowWall(1);
        if (a.state != c.state) a.ShowWall(0);

        if (a.state != RoomType.OUTSIDE) a.ShowCeiling();
    }

    private void AddRoom(Vector3 a, Vector3 b, Vector3 c, Vector3 d, RoomType roomType)
    {
        int vertexIndex = vertices.Count;
        vertices.Add(a);
        vertices.Add(b);
        vertices.Add(c);
        vertices.Add(d);
        rooms[(int)roomType - 1].Add(vertexIndex);
        rooms[(int)roomType - 1].Add(vertexIndex + 1);
        rooms[(int)roomType - 1].Add(vertexIndex + 2);
        rooms[(int)roomType - 1].Add(vertexIndex);
        rooms[(int)roomType - 1].Add(vertexIndex + 2);
        rooms[(int)roomType - 1].Add(vertexIndex + 3);
    }
}
