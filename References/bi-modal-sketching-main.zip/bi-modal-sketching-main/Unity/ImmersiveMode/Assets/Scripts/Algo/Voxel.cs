using UnityEngine;
using System;
using System.Collections.Generic;
using Newtonsoft.Json;

[JsonObject(MemberSerialization.OptIn)]
[Serializable]
public class Voxel : MonoBehaviour
{
	[JsonProperty]
	public RoomType state = RoomType.OUTSIDE;
	public GameObject[] indoorWalls;
	public GameObject[] windowWalls;
	public GameObject[] doorWalls;
	private GameObject ceiling;
	[JsonProperty]
	public float size;
	[JsonProperty]
	public int x, y;
	[JsonProperty]
	public WallType[] WallTypes;
	private readonly Transform ptransform;
	public Vector2 position, xEdgePosition, yEdgePosition, middlePosition;

	public Voxel(int x, int y, float size, Transform ptransform, GameObject indoorWallPrefab, GameObject windowWallPrefab, GameObject doorWallPrefab, GameObject ceilingPrefab)
	{

		this.ptransform = ptransform;
		indoorWalls = new GameObject[4];
		windowWalls = new GameObject[4];
		doorWalls = new GameObject[4];

		this.size = size;
		this.x = x;
		this.y = y;
		position.x = (x + 0.5f) * size;
		position.y = (y + 0.5f) * size;

		xEdgePosition = position;
		xEdgePosition.x += size * 0.5f;
		yEdgePosition = position;
		yEdgePosition.y += size * 0.5f;
		middlePosition = position;
		middlePosition.x += size * 0.5f;
		middlePosition.y += size * 0.5f;

		WallTypes = new WallType[] { WallType.WALL, WallType.WALL, WallType.WALL, WallType.WALL };

		AddWalls(indoorWalls, indoorWallPrefab);
		AddWalls(windowWalls, windowWallPrefab);
		AddWalls(doorWalls, doorWallPrefab);
        AddCeiling(ceilingPrefab);
    }

	public Voxel() { }

	public void ShowWall(int idx)
    {
		switch (WallTypes[idx])
		{
			case WallType.WALL:
				indoorWalls[idx].SetActive(true);
				break;

			case WallType.WINDOW:
				windowWalls[idx].SetActive(true);
				break;

			case WallType.DOOR:
				doorWalls[idx].SetActive(true);
				break;

			case WallType.NO_WALL:
				Debug.Log("No wall!!!");
				break;

			default:
				Debug.Log("invalid wall type");
				break;
		}
	}

	public void HideWall(GameObject[] walls, int idx)
	{
		walls[idx].SetActive(false);
	}

	public void ShowCeiling()
	{
		ceiling.SetActive(true);
	}

	public void HideCeiling()
	{
		ceiling.SetActive(false);
	}

	public void HideWalls()
	{
		indoorWalls[0].SetActive(false);
		indoorWalls[1].SetActive(false);
		indoorWalls[2].SetActive(false);
		indoorWalls[3].SetActive(false);

		windowWalls[0].SetActive(false);
		windowWalls[1].SetActive(false);
		windowWalls[2].SetActive(false);
		windowWalls[3].SetActive(false);

		doorWalls[0].SetActive(false);
		doorWalls[1].SetActive(false);
		doorWalls[2].SetActive(false);
		doorWalls[3].SetActive(false);
	}

	private void AddWalls(GameObject[] walls, GameObject wallPrefab)
    {
		walls[0] = AddWall(wallPrefab, 0);
		walls[1] = AddWall(wallPrefab, 1);
		walls[2] = AddWall(wallPrefab, 2);
		walls[3] = AddWall(wallPrefab, 3);
	}

	private GameObject AddWall(GameObject wallPrefab, int rotation)
    {
		GameObject o = Instantiate(wallPrefab) as GameObject;
		o.transform.parent = this.ptransform.parent;
		o.transform.localPosition = middlePosition;
		o.transform.localScale = Vector3.one * size;
		o.transform.rotation = ptransform.rotation;
		o.transform.Rotate(new Vector3(0, 0, 1), rotation * 90);
        o.transform.Translate(new Vector3(0, 0, -2.5f));
        o.SetActive(false);

		Wall wall = o.AddComponent<Wall>();
		wall.x = x;
		wall.y = y;
        wall.wallIndex = rotation;

        return o;
	}

	private void AddCeiling(GameObject ceilingPrefab)
    {
		GameObject o = Instantiate(ceilingPrefab) as GameObject;
		o.transform.parent = this.ptransform.parent;
		o.transform.localPosition = position;
		o.transform.localScale = Vector3.one * size;
		o.transform.rotation = ptransform.rotation;
		int rotation = 1;
		o.transform.Rotate(new Vector3(1, 0, 0), (int)rotation * 90);
		// wall size is 4, but the part over the surface is only 2
		Vector3 positionUpdate = new Vector3(0.2f * size, 0, -2.8f * size);
		o.transform.localPosition += positionUpdate;
        o.SetActive(false);

		ceiling = o;
    }

	public void BecomeXDummyOf(Voxel voxel, float offset)
	{
		state = voxel.state;
		position = voxel.position;
		xEdgePosition = voxel.xEdgePosition;
		yEdgePosition = voxel.yEdgePosition;
		position.x += offset;
		xEdgePosition.x += offset;
		yEdgePosition.x += offset;
	}

	public void BecomeYDummyOf(Voxel voxel, float offset)
	{
		state = voxel.state;
		position = voxel.position;
		xEdgePosition = voxel.xEdgePosition;
		yEdgePosition = voxel.yEdgePosition;
		position.y += offset;
		xEdgePosition.y += offset;
		yEdgePosition.y += offset;
	}

	public void BecomeXYDummyOf(Voxel voxel, float offset)
	{
		state = voxel.state;
		position = voxel.position;
		xEdgePosition = voxel.xEdgePosition;
		yEdgePosition = voxel.yEdgePosition;
		position.x += offset;
		position.y += offset;
		xEdgePosition.x += offset;
		xEdgePosition.y += offset;
		yEdgePosition.x += offset;
		yEdgePosition.y += offset;
	}
}