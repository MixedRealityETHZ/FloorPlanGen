using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    public int x, y;
    public int wallIndex;

    public Wall(int x, int y, int wallIndex)
    {
        this.x = x;
        this.y = y;
        this.wallIndex = wallIndex;
    }
}
