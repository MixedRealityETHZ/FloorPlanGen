using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneManager : MonoBehaviour
{
    public GameObject surfaceFinder { get; set; }
    private AlgoManager algoManager;
    private NetworkHandler networkHandler;

    // Start is called before the first frame update
    void Start()
    {
        surfaceFinder = GameObject.Find("SurfaceFinder");
        algoManager = FindObjectOfType<AlgoManager>();
        if (algoManager == null)
        {
            Debug.Log("AlgoManager Script not found");
        }
        networkHandler = FindObjectOfType<NetworkHandler>();
        if (networkHandler == null)
        {
            Debug.Log("NetworkHandler Script not found");
        }
    }

    public void PushFloorPlan()
    {
        StartCoroutine(networkHandler.Upload(algoManager.StringifyCurrentFloorPlan()));
    }

    public void PullFloorPlan()
    {
        StartCoroutine(networkHandler.Download(algoManager));
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.Alpha3))
        {
            StartCoroutine(networkHandler.Upload(algoManager.StringifyCurrentFloorPlan()));
            Debug.Log("Floorplan pushed to magic website from Immersive-Mode");
        }
        if (Input.GetKey(KeyCode.Alpha4))
        {
            StartCoroutine(networkHandler.Download(algoManager));
            Debug.Log("Floorplan pushed to magic website from Holo-Mode");
        }

        /// DEBUG
        if (Input.GetKey(KeyCode.Alpha1))
        {
            algoManager.SaveCurrentFloorPlan();
            Debug.Log("This action will have consequences");
        }
        if (Input.GetKey(KeyCode.Alpha2))
        {
            algoManager.LoadFloorPlan();
            Debug.Log("Butterfly");
        }
        /// END DEBUG
    }
    public void DisableSurfaceFinder()
    {
        surfaceFinder.SetActive(false);
    }
    public void EnableSurfaceFinder()
    {
        surfaceFinder.SetActive(true);
    }

    public void SwitchScene()
    {
        if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().name == "EditScene")
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene("WalkAroundScene");
        }
        else
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene("EditScene");
        }
    }
}
