using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Text;

public class NetworkHandler : MonoBehaviour
{
    private int count = 0; // not needed, only to make sure Jsons differ on upload
    void Start()
    {
    }

    async void TaskOnClick()
    {
        Debug.Log("You have clicked the button!");
        
        
        // download current state
        // StartCoroutine(Download());
    }


    public IEnumerator Upload(string json_as_str)
    {
        // TODO add argument JSON myJson, depends on format of input, replaces var myJson
        WWWForm form = new WWWForm();
        //var myJson = "{\"level\":" + count +",\"timeElapsed\":47.5,\"playerName\":\"Die Wassertropferin\"}";

        var myJson = json_as_str;
        count++;
        byte[] bytes = Encoding.UTF8.GetBytes(myJson);

        // HoloLens Upload
        //UnityWebRequest www = UnityWebRequest.Put("http://trapwired.pythonanywhere.com/HL_UP/", bytes);
        
        // VR Upload
        UnityWebRequest www = UnityWebRequest.Put("http://trapwired.pythonanywhere.com/VR_UP/", bytes);
        
        www.SetRequestHeader("Content-Type", "application/json");
        
        yield return www.SendWebRequest();

        if (www.result != UnityWebRequest.Result.Success)
        {
            Debug.Log(www.error);
        }
        else
        {
            Debug.Log("Form upload complete!");
        }
    }

    public IEnumerator Download(AlgoManager algoManager)
    {
        // HoloLens Download (from VR)
        // string uri = "http://trapwired.pythonanywhere.com/VR_UP/";

        // VR Download (from HoloLens)
        string uri = "http://trapwired.pythonanywhere.com/HL_UP/";

        using (UnityWebRequest webRequest = UnityWebRequest.Get(uri))
        {
            // Request and wait for the desired page.
            yield return webRequest.SendWebRequest();

            string[] pages = uri.Split('/');
            int page = pages.Length - 1;

            switch (webRequest.result)
            {
                case UnityWebRequest.Result.ConnectionError:
                case UnityWebRequest.Result.DataProcessingError:
                    Debug.LogError(pages[page] + ": Error: " + webRequest.error);
                    break;
                case UnityWebRequest.Result.ProtocolError:
                    Debug.LogError(pages[page] + ": HTTP Error: " + webRequest.error);
                    break;
                case UnityWebRequest.Result.Success:
                    string stuff = webRequest.downloadHandler.text;
                    Debug.Log(stuff);
                    algoManager.LoadFloorPlanFromString(stuff);
                    break;
            }
        }
    }
}
