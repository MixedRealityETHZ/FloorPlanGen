using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractionManager : MonoBehaviour
{
    // Reference to Manager Scripts
    private AlgoManager algoManager;
    private SceneManager sceneManager;
    private HuiInteraction huiInteraction;

    // Start is called before the first frame update
    void Start()
    {
        huiInteraction = FindObjectOfType<HuiInteraction>();
        if(huiInteraction == null)
        {
            Debug.Log("HuiInteraction Script not found");
        }
        algoManager = FindObjectOfType<AlgoManager>();
        if (algoManager == null)
        {
            Debug.Log("AlgoManager Script not found");
        }
        sceneManager = FindObjectOfType<SceneManager>();
        if (sceneManager == null)
        {
            Debug.Log("SceneManager Script not found");
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void SetRoomType(int roomtype)
    {
        algoManager.SetRoomType(roomtype);
    }

    public void MoveWorkspace()
    {
        sceneManager.EnableSurfaceFinder();
    }

    public void UpdateStencilRadius(bool increase)
    {
        algoManager.UpdateStencilRadius(increase);
    }
    
    public void SetStencilType(int stenciltype)
    {
        algoManager.SetStencilType(stenciltype);
    }
}
