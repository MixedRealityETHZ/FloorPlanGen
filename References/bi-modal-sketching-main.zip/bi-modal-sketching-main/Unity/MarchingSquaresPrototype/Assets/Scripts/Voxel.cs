using UnityEngine;
using System;
using System.Collections.Generic;


[Serializable]
public class Voxel : MonoBehaviour
{

	public RoomType state = RoomType.OUTSIDE;

	private List<GameObject> walls;
	private float size;
	private readonly Transform ptransform;
	public Vector2 position, xEdgePosition, yEdgePosition, middlePosition;
	public Vector2 yUWall, yDWall, xLWall, xRWall;
	public Vector2 mAWall, mBWall, mCWall, mDWall;

	public bool[] diags;

	public Voxel(int x, int y, float size, Transform ptransform)
	{
		this.ptransform = ptransform;
		this.walls = new List<GameObject>();

		this.size = size;
		position.x = (x + 0.5f) * size;
		position.y = (y + 0.5f) * size;

		xEdgePosition = position;
		xEdgePosition.x += size * 0.5f;
		yEdgePosition = position;
		yEdgePosition.y += size * 0.5f;
		middlePosition = position;
		middlePosition.x += size * 0.5f;
		middlePosition.y += size * 0.5f;

		float width = size / 20;

		yUWall = yEdgePosition;
		yDWall = yEdgePosition;
		yUWall.y += width;
		yDWall.y -= width;

		xLWall = xEdgePosition;
		xRWall = xEdgePosition;
		xLWall.x -= width;
		xRWall.x += width;

		mAWall = middlePosition;
		mBWall = middlePosition;
		mCWall = middlePosition;
		mDWall = middlePosition;

		mAWall.y -= width;
		mAWall.x -= width;

		mBWall.y -= width;
		mBWall.x += width;

		mCWall.y += width;
		mCWall.x -= width;

		mDWall.y += width;
		mDWall.x += width;

		diags = new bool[] { false, false, false, false };
	}

	public Voxel() { }

	public void AddIndoorWall(GameObject wallPrefab, int rotation)
    {
		GameObject o = Instantiate(wallPrefab) as GameObject;
		o.transform.parent = this.ptransform.parent;
		o.transform.localPosition = middlePosition;
		o.transform.localScale = Vector3.one * size;
		o.transform.Rotate(new Vector3(0, 0, 1), rotation * 90);
		walls.Add(o);
	}

	public void RemoveAllWalls()
    {
        foreach (GameObject gameObject in walls)
        {
			Destroy(gameObject);
        }
		this.walls = new List<GameObject>();
	}

	public void BecomeXDummyOf(Voxel voxel, float offset)
	{
		state = voxel.state;
		position = voxel.position;
		xEdgePosition = voxel.xEdgePosition;
		yEdgePosition = voxel.yEdgePosition;
		position.x += offset;
		xEdgePosition.x += offset;
		yEdgePosition.x += offset;
	}

	public void BecomeYDummyOf(Voxel voxel, float offset)
	{
		state = voxel.state;
		position = voxel.position;
		xEdgePosition = voxel.xEdgePosition;
		yEdgePosition = voxel.yEdgePosition;
		position.y += offset;
		xEdgePosition.y += offset;
		yEdgePosition.y += offset;
	}

	public void BecomeXYDummyOf(Voxel voxel, float offset)
	{
		state = voxel.state;
		position = voxel.position;
		xEdgePosition = voxel.xEdgePosition;
		yEdgePosition = voxel.yEdgePosition;
		position.x += offset;
		position.y += offset;
		xEdgePosition.x += offset;
		xEdgePosition.y += offset;
		yEdgePosition.x += offset;
		yEdgePosition.y += offset;
	}
}