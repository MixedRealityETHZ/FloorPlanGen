# bi-modal-sketching
Mixed Reality Course Project using Hololens 2

C# Style Guide: https://github.com/raywenderlich/c-sharp-style-guide  
Unity Style Guide: https://github.com/justinwasilenko/Unity-Style-Guide  
